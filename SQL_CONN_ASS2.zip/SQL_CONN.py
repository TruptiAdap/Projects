#!/usr/bin/env python
# coding: utf-8

# In[30]:


import psycopg2
import re


# In[31]:


DB_NAME = "Edu"
DB_USER = "postgres"
DB_PASS = "1234"
DB_HOST = "::1"
DB_PORT = "5432"
 
try:
    conn = psycopg2.connect(database=DB_NAME,
                            user=DB_USER,
                            password=DB_PASS,
                            host=DB_HOST,
                            port=DB_PORT)
    print("Database connected successfully")
    cursor = conn.cursor()
except:
    print("Database not connected successfully")


# In[32]:


with open(r"C:\Users\ASUS\Downloads\mbox.txt","r") as file:
    data = file.read()

org_from = re.findall(r'@([\w.-]+)', data)
org_received=re.findall(r'Received: from\s+(\S+)',data)


# In[37]:


org_from_count = {}
for org in org_from:
    org_from_count[org] = org_from_count.get(org, 0) + 1


# In[38]:


for x in org_from_count:
    print(x)


# In[39]:


print(org_from_count)


# In[40]:


org_rec_count = {}
for orgr in org_received:
    org_rec_count[orgr] = org_rec_count.get(orgr, 0) + 1


# In[41]:


print(org_rec_count)


# In[42]:


for a, b in org_from_count.items():
    cursor.execute("INSERT INTO counts (org, count) VALUES (%s, %s)", (a, b))


# In[43]:


for c,d in org_rec_count.items():
    cursor.execute("INSERT INTO counts (org, count) VALUES (%s, %s)", (c, d))


# In[45]:


conn.commit()
conn.close()


# In[ ]:




