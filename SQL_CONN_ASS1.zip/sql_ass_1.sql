SELECT encode((name || age)::bytea, 'hex') AS X
FROM Ages
ORDER BY X;